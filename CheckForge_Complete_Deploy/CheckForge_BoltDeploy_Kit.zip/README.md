# CheckForge for Bolt.dev

Deploy this AI-powered check generation system using Bolt.dev. Includes voice-to-check GPT server, Supabase logging, and PDF generation.